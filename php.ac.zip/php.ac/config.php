<?php
session_start();


define(LOCALHOST, 'localhost');
define(ROOt, 'root');
define(PASSWORD, '');
define(DATABASE, 'login_db');
define(SITEURL,'')

?>