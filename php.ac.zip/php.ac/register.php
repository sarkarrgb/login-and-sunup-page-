
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>my page</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <div class="register_container">
        <div class="overlay">

        </div>
        <div class="titleDiv">
                <h1 class="title">Register</h1>
            <span class="subTitle">Thanks for choosing us!</span>
        </div>
        <form action="" method="">
            <div class="row grid">
                <div class="row">
                    <label for="username">User Name</label>
                    <input type="text" id="username" name="username" placeholder="Enter user name" required>
                </div>
                <div class="row">
                    <label for="email">Email Address</Address></label>
                    <input type="email" id="email" name="email" placeholder="Email Address" required>
                </div>
                <div class="row">
                    <label for="phone">Phone Number</label>
                    <input type="phone" id="phone" name="phone" placeholder="Enter your phone number" required>
                </div>
                <div class="row">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter user password" required>
                </div>
                <div class="row">
                    <input type="submit" id="submitBtn" name="submit" value="Login" style="background-color: black;"  required>
                    <span class="registerLink"> have an account allready
                        <a href="index.html">Login</a>
                    </span>
                </div>
            </div>
        </form>
    </div>
</body>
</html>