<?php
include('partials/header.php')


?>
<div class="form_container">
        <div class="overlay">
        </div>
        <div class="titleDiv">
                <h1 class="title">Login</h1>
            <span class="subTitle">Wellcome back!</span>
        </div>
        <form action="" method="">
            <div class="row grid">
                <div class="row">
                    <label for="username">User Name</label>
                    <input type="text" id="username" name="username" placeholder="Enter user name" required>
                </div>
                <div class="row">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter user password" required>
                </div>
                <div class="row">
                    <input type="submit" id="submitBtn" name="submit" value="Login" style="background-color: black;" required>
                    <span class="registerLink">Don't have an account 
                        <a href="register.html">register</a>
                    </span>
                </div>
            </div>
        </form>
    </div>
    <?php
    include('partials/footer.php')
    ?>
