<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>my page</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <div class="dashboard">
        <span>

        </span>
        <h1>Dashboard</h1>
        <div class="lohOutBtn">
            <a href="logout.html">Log Out</a>
        </div>
    </div>
</body>
</html>