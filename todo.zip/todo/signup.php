<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Signup Page</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <form method="POST" action="./actions/signup.php" class="login-box mx-auto bg-white border rounded p-3 mt-5">
                    <h1 class="text-center">Sign Up</h1>
                    <div class="mt-4">
                        <label for="fname">Enter First Name</label>
                        <input id="fname" class="form-control" type="text" name="fname">
                    </div>
                    <div class="mt-4">
                        <label for="lname">Enter Last Name</label>
                        <input id="lname" class="form-control" type="text" name="lname">
                    </div>
                    <div class="mt-4">
                        <label for="email">Enter Email</label>
                        <input id="email" class="form-control" type="email" name="email">
                    </div>
                    <div class="mt-4">
                        <label for="password">Enter Password</label>
                        <input id="password" class="form-control" type="password" name="password">
                    </div>
                    <div class="mt-4 text-center">
                        <input type="submit" class="btn btn-success me-2" value="SignUp">
                        <input type="reset" class="btn btn-warning" value="Reset">
                    </div>
                    <div class="mt-4 text-center">
                        <a href="index.php">Login</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>