<?php

require_once('../config/connect.php');

if (
    isset($_POST)
    && isset($_POST['fname'])
    && isset($_POST['lname'])
    && isset($_POST['email'])
    && isset($_POST['password'])
) {

    $email = strip_tags($_POST['email']);
    $password = md5($_POST['password']);
    $fname = strip_tags($_POST['fname']);
    $lname = strip_tags($_POST['lname']);

    $createUser = mysqli_query(
        $conn,
        "INSERT INTO `users`(`fname`, `lname`, `email`, `password`) 
        VALUES 
        ('" . $fname . "','" . $lname . "','" . $email . "','" . $password . "')"
    ) or die(mysqli_error($conn));

    $insertId = mysqli_insert_id($conn);

    if ($insertId > 0) {
        header('Location: ../index.php?signup=success');
        exit(0);
    } else {
        header('Location: ../index.php?signup=fail');
        exit(0);
    }
}
