<?php

session_start();
require_once('../config/connect.php');

if (
    isset($_POST)
    && isset($_POST['email'])
    && isset($_POST['password'])
) {

    $email = strip_tags($_POST['email']);
    $password = md5($_POST['password']);

    $user = mysqli_query(
        $conn,
        "SELECT * FROM `users` 
        WHERE email='" . $email . "' 
        AND password='" . $password . "'"
    ) or die(mysqli_error($conn));

    $userData = mysqli_fetch_array($user);
    $_SESSION['email'] = $userData['email'];
    $_SESSION['name'] = $userData['fname'] . ' ' . $_SESSION['lname'];
    $_SESSION['id'] = $userData['id'];

    if ($userData['id']) {
        header('Location: ../home.php');
        exit(0);
    } else {
        header('Location: ../index.php?login=fail');
        exit(0);
    }
}
