<?php

define('DBHOST', 'tompkinchats.com');
define('DBUSER', 'tompkinc_app1');
define('DBNAME', 'tompkinc_app1');
define('DBPASSWORD', '+tNyN3{cv]$J');