<?php

require_once('./connect.php');

$users = mysqli_query($conn, "SELECT fname as f, lname as l FROM `users`") 
or die(mysqli_error($conn));

while ($row = mysqli_fetch_array($users)) {
    var_dump($row['f']);
    echo '<br><br><br>';
}

$user = mysqli_query($conn, "SELECT fname as f, lname as l FROM `users` LIMIT 2") 
or die(mysqli_error($conn));

$data1 = mysqli_fetch_array($user);
echo $data1['f'].' '.$data1['l'];

echo '<br><br>';

$data2 = mysqli_fetch_array($user);
var_dump($data2);

echo '<br><br>';

$data3 = mysqli_fetch_array($user);
var_dump($data3);

// $amarnaam = $data['f'].' '.$data['l'];
// echo $amarnaam;