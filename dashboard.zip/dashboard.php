<?php
include('partials/header.php')
?>
    <div class="dashboard">
        <span>

        </span>
        <h1>Dashboard</h1>
        <div class="lohOutBtn">
            <a href="logout.html">Log Out</a>
        </div>
    </div>
<?php
include('partials/footer.php');
?>