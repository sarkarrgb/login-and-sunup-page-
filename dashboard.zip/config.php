<?php

session_start();

define('LOCALHOST', 'localhost');
define('ROOT', 'root');
define('PASSWORD', '');
define('DATABASE', 'login_db');
define('SITEURL', 'http://localhost/php.ac/');

$conn = mysqli_connect(LOCALHOST, ROOT, PASSWORD, DATABASE) or die('Failed to connect!');
$db_select = mysqli_select_db($conn, DATABASE) or die('Failed to select Database!');



?>